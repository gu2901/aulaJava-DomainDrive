package br.com.fiap.tds.bean;

public class Carro {
//Atributos
public String modelo;
public String marca;
public int ano;
public float motor;
public double preco;
public boolean automatico;


	
	
	
	
	
	
//Metodos	
	
	
	
}
